# Kaifiya's Birthday Website 💗

## Preview
Open `index.html` in a modern browser. It is mobile-friendly and uses no external libraries.

## Personalize it
- Search for `Shaaz` in `index.html` and replace it with your preferred signature.
- The gallery lets you preview photos locally. To make your photos appear for everyone after publishing, create a `photos` folder and use image files such as `photos/our-photo-1.jpg`. Replace each gallery image element's empty `src` with the appropriate filename and remove/hide the upload input if you prefer a fixed gallery.
- The music button creates a short original chime melody using the browser. It does not require an audio file.

## Publish free with GitHub Pages
1. Sign in or create an account at https://github.com/
2. Create a new public repository, for example `kaifiya-birthday`.
3. Upload `index.html` (and your `photos` folder if you add photos).
4. Open the repository's **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
6. Wait a minute or two. GitHub will show a website URL similar to `https://YOUR-USERNAME.github.io/kaifiya-birthday/`.
7. Open the link on your phone to test it, then send it to Kaifiya on WhatsApp.

## Share safely
Only include photos and personal details you both feel comfortable sharing. A public GitHub Pages website can be viewed by anyone with the link (and may be discoverable), so avoid private information.
